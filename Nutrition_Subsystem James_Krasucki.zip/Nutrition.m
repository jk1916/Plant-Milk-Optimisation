
%%Minimising difference of key nutrients using fminmax
obj4 = @(x) goal(x); %call function

T = readmatrix('Matlab_data.xlsx'); %read excel table
T(1:6,1:20); 
DF1 = T(1,2:9); %create array of defficiency factors for first 8 nutrients
D1 = T(2,2:9); %create array of dairy values for first 8 nutrients

x0 = [1,1,1,1]; %create starting values

A = [1,1,1,1;
    -1,0,0,0;
    0,-1,0,0;
    0,0,-1,0;
    0,0,0,-1;
    1,0,0,0;
    0,1,0,0;
    0,0,1,0;
    0,0,0,1;
    0.0131,0.033,0.0121,0.045;
    0.0304,0.015,0.005,0.043;
    0.0000101,0.00005,0.00002,0;
    1.73,5.53,3.89,6.28]; %create constraints

b =[160;
    0;
    0;
    0;
    0;
    128;
    47;
    143;
    46;
    5.467; 
    53;
    0.136;
    400]; %create constraints

Aeq = []; %no equality constraints
beq = [];

lb = [0,0,0,0]; %lower bound of grams of each crop
ub = []; %upper bound of soy, hemp, oat, hazelnut

nonlcon = []; %no nonlinear constraints

   
[x,fval] = fminimax(obj4,x0,A,b,Aeq,beq,lb,ub) %minimise the difference of each nutrient for dairy and each the sum of each plant crop

Nut1 = x'.*NF'
Profile1 = [sum(Nut1(1:4,1)),sum(Nut1(1:4,2)),sum(Nut1(1:4,3)),sum(Nut1(1:4,4)),sum(Nut1(1:4,5)),sum(Nut1(1:4,6)),sum(Nut1(1:4,7)),sum(Nut1(1:4,8)),sum(Nut1(1:4,9)),sum(Nut1(1:4,10)),sum(Nut1(1:4,11)),sum(Nut1(1:4,12)),sum(Nut1(1:4,13)),sum(Nut1(1:4,14)),sum(Nut1(1:4,15)),sum(Nut1(1:4,16)),sum(Nut1(1:4,17)),sum(Nut1(1:4,18)),sum(Nut1(1:4,19)),sum(Nut1(1:4,20))]

%% Minimising Difference of key nutrients using fmincon
obj1 = @(x) lsq(x); %call least squares function

x0 = [1,1,1,1]; %starting values

A =[1,1,1,1;
    -1,0,0,0;
    0,-1,0,0;
    0,0,-1,0;
    0,0,0,-1;
    1,0,0,0;
    0,1,0,0;
    0,0,1,0;
    0,0,0,1;
    0.0131,0.033,0.0121,0.045;
    0.0304,0.015,0.005,0.043;
    0.0000101,0.00005,0.00002,0;
    1.73,5.53,3.89,6.28
    ]; %linear constraints

b=[160;
   0;
   0;
   0;
   0;
   128;
   47;
   143;
   46;
   5.467; 
   53;
   0.136;
   400
   ]; %linear constrain values

Aeq = [];
beq = []; %no equality constraints

lb = []; %lower bound of soy, hemp, oat, hazelnut
ub = []; %upper bound of soy, hemp, oat, hazelnut

nonlcon = []; %no nonlinear constraints
%,'PlotFcn','optimplotfval'
% for cal = 0:10:600
options = optimoptions('fmincon','Display','iter','Algorithm','sqp'); %find active set of solutions
[y,gval] = fmincon(obj1,x0,A,b,Aeq,beq,lb,ub,nonlcon,options) %minimise sum of squares of difference between dairy and sum of plant crops
% end 

Nut2 = y'.*NF'
Profile2 = [sum(Nut2(1:4,1)),sum(Nut2(1:4,2)),sum(Nut2(1:4,3)),sum(Nut2(1:4,4)),sum(Nut2(1:4,5)),sum(Nut2(1:4,6)),sum(Nut2(1:4,7)),sum(Nut2(1:4,8)),sum(Nut2(1:4,9)),sum(Nut2(1:4,10)),sum(Nut2(1:4,11)),sum(Nut2(1:4,12)),sum(Nut2(1:4,13)),sum(Nut2(1:4,14)),sum(Nut2(1:4,15)),sum(Nut2(1:4,16)),sum(Nut2(1:4,17)),sum(Nut2(1:4,18)),sum(Nut2(1:4,19)),sum(Nut2(1:4,20))]
compval = [Profile1;Profile2]
compvar = categorical({'protein','calcium','potassium','vitamin a','vitamin e','vitamin k','B2','Unsaturated fat','fibre','iron','magnesium','vitamin c','zinc','B1','B3','B6','saturated fat','sugar','sodium','calories'});
% X = reordercats(X,{'protein','calcium','potassium','vitamin a','vitamin e','vitamin k','B2','Unsaturated fat','fibre','iron','magnesium','vitamin c','zinc','B1','B3','B6','saturated fat','sugar','sodium','calories'});

bar(compvar,compval)
% X = [0:25:600]
% Y = [191,163,138,114.8,93.7,74.8,58,43.4,30.9,21,15.8,11.31,7.6,4.64,2.4,0.99,0.3,0.23,0.23,0.23,0.23,0.25,0.25,0.24,0.24];
% x1 = [0,14.5,28.9,43.4,57.8,72.3,86.7,101.2,115.6,128,128,128,128,128,128,128,127.6,121.4,115.8,110.2,104.6,63.4,58.8,54.2,49.6]
% x2 = [0,0,0,0,0,0,0,0,0,0.6,5.2,9.7,14.2,18.7,23.2,27.8,32.4,36.7,37.2,37.8,38.3,47,47,47,47]
% x3 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,38.8,38.5,38.1,37.8]
% x4 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1.9,7,12,17.1,0.71,6.2,11.6,17.1] 
% 
% figure
% scatter(X,Y)
% title('Effect of Calorie Constraint (g13) on f1')
% xlabel('Calories (Kcal)')
% ylabel('f1')
% 
% 
% figure
% scatter(X,x1)
% hold on
% scatter(X,x2)
% scatter(X,x3)
% scatter(X,x4)
% title('Effect of Calorie Constraint on Crop Content')
% xlabel('Calories (Kcal)')
% ylabel('Mass of Crop in Final Product (g)')
%% Maximising Healthy Nutrients using linprog
T = readmatrix('Matlab_data.xlsx'); %read table from excel
T(1:6,1:20);
NF = T(3:6,2:21);
% NF = [T(3,2:21);
%     T(4,2:21);
%     T(5,2:21);
%     T(6,2:21)];
DF2 = T(1,10:17); %create array of defficiency factors for nutrients 10 to 17 

NF2 = [T(3,10:17);
    T(4,10:17);
    T(5,10:17);
    T(6,10:17)]; %create array of nutrient proportions for each crop
NFX2 = DF2.*NF2; %multiply nutrient proportions by deficiency factor to achieve scaled goal values
A2 = [sum(NFX2(1,1:8)),sum(NFX2(2,1:8)),sum(NFX2(3,1:8)),sum(NFX2(4,1:8))]; %sum coefficients for x1 (soy), x2 (hemp), x3 (oat), x4 (hazelnut)
obj3 = -A2; %create objective coefficients (in negative null form
A =[1,1,1,1;
    -1,0,0,0;
    0,-1,0,0;
    0,0,-1,0;
    0,0,0,-1;
    1,0,0,0;
    0,1,0,0;
    0,0,1,0;
    0,0,0,1;
    0.0131,0.033,0.0121,0.045;
    0.0304,0.015,0.005,0.043;
    0.0000101,0.00005,0.00002,0;
    1.73,5.53,3.89,6.28
    ]; %inequality constraint coefficients

b =[160;
    0;
    0;
    0;
    0;
    128;
    47;
    143;
    46;
    5.467; 
    53;
    0.136;
    400
    ]; %inequality constrain bounds

Aeq = [];
beq = []; %no equality constraints

lb = []; %lower bound of soy, hemp, oat, hazelnut
ub = []; %upper bound of soy, hemp, oat, hazelnut

[w,eval] = linprog(obj3,A,b,Aeq,beq,lb,ub) %use linear programming optimisation to solve maximise problem by minimising null form

Nut3 = w.*NF
Profile3 = [sum(Nut3(1:4,1)), sum(Nut3(1:4,2)), sum(Nut3(1:4,3)), sum(Nut3(1:4,4)), sum(Nut3(1:4,5)), sum(Nut3(1:4,6)), sum(Nut3(1:4,7)), sum(Nut3(1:4,8)), sum(Nut3(1:4,9)), sum(Nut3(1:4,10)), sum(Nut3(1:4,11)), sum(Nut3(1:4,12)), sum(Nut3(1:4,13)), sum(Nut3(1:4,14)), sum(Nut3(1:4,15)), sum(Nut3(1:4,16)), sum(Nut3(1:4,17)), sum(Nut3(1:4,18)), sum(Nut3(1:4,19)), sum(Nut3(1:4,20))]


%% Multiobjective - obtaining multiobjective solutions to minimise difference and maximise beneficial nutrients 

fun = @(x) big_obj(x); %call multiobjective function

T = readmatrix('Matlab_data.xlsx'); %read excel table
T(1:6,1:20);

NF = [T(3,2:21)
    T(4,2:21)
    T(5,2:21)
    T(6,2:21)];
NF = [T(3:6,2:21)]';

D = [T(2,2:21)]; %nutrient values for dairy

x0 = [1,1,1,1]; %starting values 

A = [1,1,1,1;
    1,0,0,0;
    0,1,0,0;
    0,0,1,0;
    0,0,0,1;
    0.0131,0.033,0.0121,0.045;
    0.0304,0.015,0.005,0.043;
    0.0000101,0.00005,0.00002,0;
    1.73,5.53,3.89,6.28]; %inequality constraint coefficients

b=[160;
    128;
    47;
    143;
    46;
    5.467; 
    53;
    0.136;
    400]; %inequality constraint bounds

Aeq = [];
beq = []; %no equality constraints

lb = [0,0,0,0]; %lower bound of soy, hemp, oat, hazelnut
ub = []; %upper bound of soy, hemp, oat, hazelnut

nonlcon = []; %no nonlinear constraints
options = optimoptions('gamultiobj','MaxGenerations',2,'PlotFcn','gaplotpareto'); %plot pareto front as algorithm runs
%[u,cval,exitflag,output,residuals]=paretosearch(fun,4,A,b,[],[],lb,ub,[]); %use pareto search algorithm
[t,bval,exitflag,output,population,scores] = gamultiobj(fun,4,A,b,Aeq,beq,lb,ub,options); %use multiobjective algorithm 

[numRows,numCols] = size(t); %size of array containing solutions
I = numRows; %create variable 'I' which counts number of solutions

for i = 1:I %create for loop to extract solutions individually from array
    newt = strcat('x',num2str(i)); %create structure that contains each solution
    sol.(newt) = t(i,1:4);
    sol.(newt) = (sol.(newt)).*NF %multiply solutions by nutrient proportions to get actual amount of each nutrient in solutions
    sol.(newt) = [sum(sol.(newt)(1,1:4)),sum(sol.(newt)(2,1:4)),sum(sol.(newt)(3,1:4)),sum(sol.(newt)(4,1:4)),sum(sol.(newt)(5,1:4)),sum(sol.(newt)(6,1:4)),sum(sol.(newt)(7,1:4)),sum(sol.(newt)(8,1:4)),sum(sol.(newt)(9,1:4)),sum(sol.(newt)(10,1:4)),sum(sol.(newt)(11,1:4)),sum(sol.(newt)(12,1:4)),sum(sol.(newt)(13,1:4)),sum(sol.(newt)(14,1:4)),sum(sol.(newt)(15,1:4)),sum(sol.(newt)(16,1:4)),sum(sol.(newt)(17,1:4)),sum(sol.(newt)(18,1:4)),sum(sol.(newt)(19,1:4)),sum(sol.(newt)(20,1:4))];
    sol.(newt) = sol.(newt)%sum the amount of each nutrient from each crop to create a total nutrient value for that solution
   
end

Y = D; %create array Y that can be used to compare dairy nutrient values and solution nutrient values

for j = [1:length(fieldnames(sol))] %loop to add each solution to comparison array
    test = sol.(strcat('x',num2str(j)))
    Y(j+1,:) = test;
end

%solution visualisation

%create nutrient names for graphs
X = categorical({'protein','calcium','potassium','vitamin a','vitamin e','vitamin k','B2','Unsaturated fat','fibre','iron','magnesium','vitamin c','zinc','B1','B3','B6','saturated fat','sugar','sodium','calories'});
X = reordercats(X,{'protein','calcium','potassium','vitamin a','vitamin e','vitamin k','B2','Unsaturated fat','fibre','iron','magnesium','vitamin c','zinc','B1','B3','B6','saturated fat','sugar','sodium','calories'});
J = normalize(Y);
figure(); 
bar(X,J) %create bar graph of all solutions and dairy nutrient values
title('Solutions vs Dairy')
xlabel('Nutrients')
ylabel('Normalised Nutrient Score')
Ymacro = [Y(1:19,1),Y(1:19,9),Y(1:19,8),Y(1:19,17),Y(1:19,18)]; %solutions macro nutrient values
Xmacro = categorical({'protein','fibre','Unsaturated fat','saturated fat','sugar'}); %create nutrient names for graphs
Xmacro = reordercats(Xmacro,{'protein','fibre','Unsaturated fat','saturated fat','sugar'}) 
lgd = legend('Dairy');
figure();
bar(Xmacro,Ymacro) %bar graph of macronutrient value comparison
title('Solutions vs Dairy')
xlabel('Macronutrients')
ylabel('Nutrient Score')
lgd = legend('Dairy');
Ymicro = [Y(1:19,2),Y(1:19,3),Y(1:19,4),Y(1:19,5),Y(1:19,6),Y(1:19,7),Y(1:19,10),Y(1:19,11),Y(1:19,12),Y(1:19,13),Y(1:19,14),Y(1:19,15),Y(1:19,16),Y(1:19,19)] %solutions micronutrient values
Xmicro = categorical({'calcium','potassium','vitamin a','vitamin e','vitamin k','B2','iron','magnesium','vitamin c','zinc','B1','B3','B6','sodium'});%create nutrient names for graphs
Xmicro = reordercats(Xmicro,{'calcium','potassium','vitamin a','vitamin e','vitamin k','B2','iron','magnesium','vitamin c','zinc','B1','B3','B6','sodium'})
figure();
bar(Xmicro,Ymicro) %bar graph of micronutrient value comparison
title('Solutions vs Dairy')
xlabel('Micronutrients')
ylabel('Nutrient Score')
lgd = legend('Dairy');
Ycal = [Y(1:19,20)]; %solution and dairy calorie values
Xcal = categorical({'calories'}); %create nutrient names for graphs
figure();
bar(Xcal,Ycal) %bar graph of calorie value comparison
title('Solutions vs Dairy')
xlabel('-')
ylabel('Calories')
lgd = legend('Dairy');


Ymaccomp = [Y(1,1),Y(1,9),Y(1,8),Y(1,17),Y(1,18);Y(18,1),Y(18,9),Y(18,8),Y(18,17),Y(18,18)]; %solutions macro nutrient values
Xmaccomp = categorical({'protein','fibre','Unsaturated fat','saturated fat','sugar'}); %create nutrient names for graphs
Xmaccomp = reordercats(Xmaccomp,{'protein','fibre','Unsaturated fat','saturated fat','sugar'}) 
figure();
macbar = bar(Xmaccomp,Ymaccomp) %bar graph of macronutrient value comparison of possible solution
title('Possible Solution vs Dairy')
xlabel('Macronutrients')
ylabel('Nutrient Score')
lgd = legend('Dairy','Possible Solution');

xtips1 = macbar(1).XEndPoints;
ytips1 = macbar(1).YEndPoints;
labels1 = string(macbar(1).YData);
text(xtips1,ytips1,labels1,'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
xtips2 = macbar(2).XEndPoints;
ytips2 = macbar(2).YEndPoints;
labels2 = string(macbar(2).YData);
text(xtips2,ytips2,labels2,'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')

Ymiccomp = [Y(1,2),Y(1,3),Y(1,4),Y(1,5),Y(1,6),Y(1,7),Y(1,10),Y(1,11),Y(1,12),Y(1,13),Y(1,14),Y(1,15),Y(1,16),Y(1,19);Y(18,2),Y(18,3),Y(18,4),Y(18,5),Y(18,6),Y(18,7),Y(18,10),Y(18,11),Y(18,12),Y(18,13),Y(18,14),Y(18,15),Y(18,16),Y(18,19)]; %solutions macro nutrient values
Xmiccomp = categorical({'calcium','potassium','vitamin a','vitamin e','vitamin k','B2','iron','magnesium','vitamin c','zinc','B1','B3','B6','sodium'});%create nutrient names for graphs
Xmiccomp = reordercats(Xmiccomp,{'calcium','potassium','vitamin a','vitamin e','vitamin k','B2','iron','magnesium','vitamin c','zinc','B1','B3','B6','sodium'})
figure();
micbar = bar(Xmiccomp,Ymiccomp) %bar graph of macronutrient value comparison of possible solutions
title('Solutions vs Dairy')
xlabel('Micronutrients')
ylabel('Normalised Nutrient Score')
lgd = legend('Dairy','Possible Solution');


Ycalcomp = [Y(1,20);Y(18,20)]; %solution and dairy calorie values
Xcalcomp = categorical({'calories'}); %create nutrient names for graphs
figure();
calbar = bar(Xcalcomp,Ycalcomp)
title('Possible Solution vs Dairy')
xlabel('-')
ylabel('Calories')
lgd = legend('Dairy','Possible Solution');

xtips1 = calbar(1).XEndPoints;
ytips1 = calbar(1).YEndPoints;
labels1 = string(calbar(1).YData);
text(xtips1,ytips1,labels1,'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')
xtips2 = calbar(2).XEndPoints;
ytips2 = calbar(2).YEndPoints;
labels2 = string(calbar(2).YData);
text(xtips2,ytips2,labels2,'HorizontalAlignment','center',...
    'VerticalAlignment','bottom')

%% Using Healthy Nutrients as a Constraint, Minimising Difference with fminimax

obj4 = @(x) goal(x); %call function
maxcon = @(x) max(x);
T = readmatrix('Matlab_data.xlsx'); %read excel table
T(1:6,1:20); 
DF1 = T(1,2:9); %create array of defficiency factors for first 8 nutrients
D1 = T(2,2:9); %create array of dairy values for first 8 nutrients

x0 = [1,1,1,1]; %create starting values

A = [1,1,1,1;
    -1,0,0,0;
    0,-1,0,0;
    0,0,-1,0;
    0,0,0,-1;
    1,0,0,0;
    0,1,0,0;
    0,0,1,0;
    0,0,0,1;
    0.0131,0.033,0.0121,0.045;
    0.0304,0.015,0.005,0.043;
    0.0000101,0.00005,0.00002,0;
    1.73,5.53,3.89,6.28;
    ]; %create constraints

b =[160;
    0;
    0;
    0;
    0;
    128;
    47;
    143;
    46;
    5.467; 
    53;
    0.136;
    400]; %create constraints

Aeq = []; %no equality constraints
beq = [];

lb = [0,0,0,0]; %lower bound of grams of each crop
ub = []; %upper bound of soy, hemp, oat, hazelnut

nonlcon = [maxcon]; %set non linear constraints as maximise healthy nutrients function

  
[fin,finval] = fminimax(obj4,x0,A,b,Aeq,beq,lb,ub) %minimise the difference of each nutrient for dairy and the sum of each plant crop

Nut4 = fin'.*NF';
Profile4 = [sum(Nut4(1:4,1)),sum(Nut4(1:4,2)),sum(Nut4(1:4,3)),sum(Nut4(1:4,4)),sum(Nut4(1:4,5)),sum(Nut4(1:4,6)),sum(Nut4(1:4,7)),sum(Nut4(1:4,8)),sum(Nut4(1:4,9)),sum(Nut4(1:4,10)),sum(Nut4(1:4,11)),sum(Nut4(1:4,12)),sum(Nut4(1:4,13)),sum(Nut4(1:4,14)),sum(Nut4(1:4,15)),sum(Nut4(1:4,16)),sum(Nut4(1:4,17)),sum(Nut4(1:4,18)),sum(Nut4(1:4,19)),sum(Nut4(1:4,20))]



    