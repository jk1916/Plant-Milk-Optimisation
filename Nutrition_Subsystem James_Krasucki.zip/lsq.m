function[obj1] = lsq(x)

T = readmatrix('Matlab_data.xlsx');
T(1:6,1:20);
DF1 = T(1,2:9);
x = x'
NF1 = [T(3,2:9)
    T(4,2:9)
    T(5,2:9)
    T(6,2:9)];
DF2 = T(1,10:17);
NF2 = [T(3,10:17)
    T(4,10:17)
    T(5,10:17)
    T(6,10:17)];

NFX1 = x.*NF1;
D1 = T(2,2:9);
A1 = [sum(NFX1(1:4,1)),sum(NFX1(1:4,2)),sum(NFX1(1:4,3)),sum(NFX1(1:4,4)),sum(NFX1(1:4,5)),sum(NFX1(1:4,6)),sum(NFX1(1:4,7)),sum(NFX1(1:4,8))];
ob1 = DF1.*(D1-A1).^2;
obj1 = sum(ob1(1,1:4));
end