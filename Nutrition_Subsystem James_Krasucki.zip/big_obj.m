function[z] = big_obj(x)
z = zeros(1,2); % allocate output
z(1) = lsq(x);
z(2) = max(x);
end 
